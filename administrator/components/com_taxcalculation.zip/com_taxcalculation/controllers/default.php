defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\AdminController;

class TaxCalculationControllerDefault extends AdminController
{
    public function display($cachable = false, $urlparams = false)
    {
	parent::display($cachable, $urlparams);
    }
}