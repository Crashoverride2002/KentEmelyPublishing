defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView;

class TaxCalculationsViewTaxs extends HtmlView
{
    public function display($tpl = null)
    {
	parent display($tpl);
    }
}
